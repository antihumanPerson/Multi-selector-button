//
//  radioButtonView.h
//  Yeos
//
//  Created by 潘东 on 16/5/23.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^ReturnBtnClick) (NSMutableArray *btnTitleArr);//声明一个block

@interface radioButtonView : UIView
@property (strong, nonatomic) NSArray *btnTitleArr;
//声明block属性
@property (copy,  nonatomic) ReturnBtnClick returnBtnClickBlock;
//创建一个Block语句块的函数
-(void)returnBtnClickBlock:(ReturnBtnClick)block;
@end
