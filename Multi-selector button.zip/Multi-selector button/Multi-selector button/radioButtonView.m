//
//  radioButtonView.m
//  Yeos
//
//  Created by 潘东 on 16/5/23.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import "radioButtonView.h"
@interface radioButtonView ()
{
    CGFloat x;
    CGFloat y;
    CGFloat w;
    CGFloat h;
    CGFloat gap;
}
@property (strong, nonatomic) NSMutableArray *titleArr;//按钮title数组
@property (strong, nonatomic) NSMutableArray *btnArr;//按钮数组
@property (strong, nonatomic) UIButton *btn;//用来记录选中的按钮
@end
@implementation radioButtonView
-(instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        w = 0.0;
        y = 0.0;
        w = 100;
        h = 24;
        gap = 8;
    }
    return self;
}
-(void)setBtnTitleArr:(NSMutableArray *)btnTitleArr
{
    for (int i = 0 ; i < btnTitleArr.count; i++) {
        UIButton *btn = [[UIButton alloc]init];
        [btn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];//普通状态
        [btn setBackgroundImage:[UIImage imageNamed:@"unchecked"] forState:UIControlStateNormal];
        
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];//选中状态
        [btn setBackgroundImage:[UIImage imageNamed:@"checked"] forState:UIControlStateSelected];
        
        //按钮文字
        [btn setTitle:btnTitleArr[i] forState:UIControlStateNormal];
        btn.titleLabel.font = [UIFont systemFontOfSize:12.0f];//按钮文字大小
        btn.titleEdgeInsets = UIEdgeInsetsMake(0, 0, 4, 0);//文字偏移量
        btn.showsTouchWhenHighlighted=YES;//特效
        
        [btn addTarget:self action:@selector(btnClick:) forControlEvents:UIControlEventTouchUpInside];
        btn.tag = i;
        btn.frame = CGRectMake(x, y, w, h);
        y += h + gap;
        [self addSubview:btn];
        [self.btnArr addObject:btn];//添加到按钮数组
    }
}
-(void)btnClick:(UIButton *)btn
{
    btn.selected = !btn.selected;
    [self.titleArr removeAllObjects];
    for (NSInteger i = 0; i < self.btnArr.count; i ++) {//便利按钮数组
        self.btn = self.btnArr[i];//记录选中的
        if (self.btn.selected) {
            [self.titleArr addObject:self.btn.titleLabel.text];// 把标题添加到数组中
        }
    }
    if (self.returnBtnClickBlock) {
        self.returnBtnClickBlock(self.titleArr);
    }
}
-(void)returnBtnClickBlock:(ReturnBtnClick)block
{
    if (block) {
        self.returnBtnClickBlock = block;
    }
}
#pragma mark - 数组懒加载
-(NSMutableArray *)titleArr
{
    if (!_titleArr) {
        _titleArr = [NSMutableArray array];
    }
    return _titleArr;
}
-(NSMutableArray *)btnArr
{
    if (!_btnArr) {
        _btnArr = [NSMutableArray array];
    }
    return _btnArr;
}

@end
