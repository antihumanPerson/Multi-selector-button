//
//  ViewController.m
//  Multi-selector button
//
//  Created by 潘东 on 16/7/5.
//  Copyright © 2016年 Dream. All rights reserved.
//

#import "ViewController.h"
#import "radioButtonView.h"
@interface ViewController ()
@property (strong, nonatomic) radioButtonView *radioButtonView;
@end

@implementation ViewController
-(radioButtonView *)radioButtonView
{
    if (!_radioButtonView) {
        _radioButtonView = [[radioButtonView alloc]init];
        [self.view addSubview:_radioButtonView];
    }
    return _radioButtonView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    CGFloat width = [UIScreen mainScreen].bounds.size.width;
    CGFloat height = [UIScreen mainScreen].bounds.size.height;
    NSArray *arr = @[@"全部",@"文章",@"片段",@"视频",@"照片"];//按钮title数组
    self.radioButtonView.btnTitleArr = arr;//传一个数组进去
    
    CGFloat radioButtonViewH = 34 * arr.count;//计算高度
    self.radioButtonView.frame = CGRectMake(width-102, (height-radioButtonViewH)/2, 102, radioButtonViewH);
    //block回调
    [self.radioButtonView returnBtnClickBlock:^(NSMutableArray *btnTitleArr) {
        for (NSString *str in btnTitleArr) {
            NSLog(@"%@",str);
        }
    }];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
